
## Q-WordNet: Extracting Positive and Negative Polarity from WordNet senses ##

Version 0.3 (last modified 13 May 2010) 

### Summary ####

1. Contact. 
2. Contents of Q-WordNet-0.3. 
3. Description and example of Q-WordNet.
4. Ongoing work for future releases. 

#### Contact #### 

Rodrigo Agerri
rodrigo.agerri@ehu.es
IXA NLP Group, University of the Basque Country (UPV/EHU) 
Donostia-San Sebastián

#### Contents of Q-WordNet 0.3 ####

Q-WordNet annotates WordNet synsets by their polarity. Current version uses
WordNet linguistic information only. Different versions are provided, each of
them based on WordNet versions 1.6, 1.7, 2.0 and 3.0:

(a) Q-WordNet based on WordNet 1.6 contains 4012 positive and negative synsets. 
(b) Q-WordNet based on WordNet 1.7 contains 4063 positive and negative
synsets. 
(c) Q-WordNet based on WordNet 2.0 consists of 4984 positive and
negative synsets. 
(d) Q-WordNet based on WordNet 3.0 includes 15510 positive
and negative synsets. 

Q-WordNet was originally developed for WordNet 3.0; the WordNet 2.0 version
was built for intrinsic evaluation purposes with respect to SentiWordNet 1.0.
Furthermore, the ones based on 1.6 and 1.7 are built for compatibility
purposes with other lexical resources, including multilingual resources. As the present
version of Q-WordNet is entirely based on WordNet semantic and lexical relations, we
can directly generate Q-WordNets for other WordNets in English or in any other
language. Q-WordNet is work in progress. It can be used in its current state
for polarity classification tasks or as a training set for the development of
alternative classifiers and/or resources. 

1. A positive and negative txt files, containing positive and negative synsets
extracted from WordNet. The file format consist of offset, synset name and
polarity value. 

2. One xml file containing all positive and negative synsets extracted from
WordNet. Every synset element consists of their offset, synset name, POS,
definition, lemma_names, examples and polarity value. 

3. qwn.dtd is the document type description (DTD) for Q-WordNet. 

4. LICENSE 

5. This README.txt

6. qwnlong.pdf is a summary of Q-WordNet building process and its intrinsic
evaluation and comparison with a related resource such as SentiWordNet1.0. 
This is the reference paper, published at LREC 2010: 

http://www.lrec-conf.org/proceedings/lrec2010/summaries/695.html. 
 
#### Description of Q-WordNet ####

See qwnlong.pdf document for a detailed description of how Q-WordNet is built. Alternatively, check the paper here: 

http://www.lrec-conf.org/proceedings/lrec2010/summaries/695.html. 

#### Versions ####

Ongoing work towards version 1.0:

    1. Integrating WSD for glosses extracted from glosstag, a semantically
    annotated gloss corpus (http://wordnet.princeton.edu/glosstag.shtml). 
    2. Calculate WSD with ukb (Agirre and Soroa, 2009 at EACL-09) as an 
    alternative to 1. 
    3. Include treatment of glosses.
    4. Calculate graded polarity using similarity measures. 
    5. Extrinsic evaluation on shared tasks such as Affective Text at SemEval07.
    6. Multilinguality. Due to its nature, the algorithm used to built Q-WordNet
    is directly exportable for other WordNets without further work. 
    Unfortunately, the majority of those WordNets (based on EuroWordNet) 
    are not free. 

#### 
